<template>
  <div v-if="show" class="modal">
    <div class="box">
      <img src="../../../static/trade/checkFail.png" alt="">
      <div class="msg">{{msg}}</div>
      <button :class="{LButton:button}" @click="yes">确定</button>
      <button v-if="button" @click="no">取消</button>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        show: false,
        msg:'',
        button:false,
        yes_fun:undefined,
        no_fun:undefined,
      }
    },
    methods: {
      yes(){
        this.show = false;
        this.yes_fun();
      },
      no(){
      	this.show=false;
      	this.no_fun();
      }
    },
    computed: {},
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .modal {
    width: 100vw;
    height: 100vh;
    background-color: rgba(0, 0, 0, .3);
    position: absolute;
    top: 0;
    left: 0;
  }
  .box{
    padding:20px 20px 0 20px;
    text-align: center;
    font-size: 26px;
    border-radius: 6px;
    background-color: white;
    display: inline-block;
    position: absolute;
    left: 0;
    right: 0;
    top:0;
    bottom: 0;
    margin: auto;
    width:460px;
    height: 200px;
      	/*box-sizing: border-box;*/
  }
  img{
    display: block;
    width: 40px;
    height: 40px;
    margin: 10px  auto;
    border-style: none;
  }
  .msg{
    text-align: center;
    padding-top: 10px;
    margin: 0 auto;
    max-width: 400px;
  }
  button{
    height: 36px;
    width: 110px;
    font-size: 22px;
    position: absolute;
    bottom: 30px;
    margin: 0;
    right: 70px;
  }
  .LButton{
  	background-color: white;
  	color: #E74A41;
  	left: 70px;
  }
</style>
